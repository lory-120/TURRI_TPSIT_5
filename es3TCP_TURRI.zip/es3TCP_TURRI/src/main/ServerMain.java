package main;

import model.ServerTCP;

public class ServerMain {
	
    public static void main(String[] args) {
    	
        ServerTCP server = new ServerTCP();
        server.avvia();
        
    }
    
}